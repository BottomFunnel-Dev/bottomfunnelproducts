import styles from "./LandingTrafic.module.css"

export const LandingTrafic = () => {
    return (
        <div className={styles.LandingTraficParent}>
            <h1>Convert traffic into leads</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora, temporibus dolore in facere, harum quidem earum vel magnam ad voluptas voluptatum. Fuga temporibus accusamus, quos dignissimos totam dolore omnis neque! Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit ratione inventore voluptatum tempora! Hic assumenda deserunt nam asperiores quos nobis fugit, quidem eos, debitis perferendis necessitatibus impedit doloremque non? Cum!</p>
        </div>
    )
}