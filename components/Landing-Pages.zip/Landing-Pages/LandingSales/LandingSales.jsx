import styles from "./LandingSales.module.css"

export const LandingSales = () => {
    return (
        <div className={styles.LandingSalesPerent} >
            <h1>Get your landing page builder with bottom funnnel sales suite marketers</h1>
            <p>Start your 21-days trail.create card required</p>
            <button>Start Demo</button>
        </div>
    )
}