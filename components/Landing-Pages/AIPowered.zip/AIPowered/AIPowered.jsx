import styles from "./AIPowered.module.css"
export const AIPowered = () => {
    return (
        <div className={styles.AIPoweredParent}>
           <h3>Bottom funnel Sales Suits combines the power of sales, marketing, chat, and telephony in one AI-powered solution</h3>
        <ul>
            <li>Attract the beast leads with personilized massages.</li>
            <li>Engage across channels - phones ,emails, whatsapp, chat    </li>
            <li> close deals faster with Ai-powered insights </li>
            <li> Deliver personized experience with 360 customer context</li>
        </ul>
        </div>
    )
}