import React from "react";
import styles from "./industryExperts.module.css";

export const IndustryExperts = () => {
  return (
    <div className={styles.industryExperts}>
      <h1>Leading industry experts recommend Bottom Funnel SupportDesk</h1>
    </div>
  );
};
